'use client';
import { useEffect, useState } from 'react';

type BIP = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

export default function InstallPrompt() {
  const [evt, setEvt] = useState<BIP | null>(null);
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    try { if (localStorage.getItem('samascore.install.dismissed')) return; } catch {}
    const h = (e: Event) => { e.preventDefault(); setEvt(e as BIP); setHidden(false); };
    window.addEventListener('beforeinstallprompt', h);
    return () => window.removeEventListener('beforeinstallprompt', h);
  }, []);

  if (hidden || !evt) return null;
  return (
    <div className="card card-body install">
      <p>Installe <b>SamaScore</b> sur ton téléphone : plus rapide, moins de data.</p>
      <button className="btn primary small" onClick={async () => { await evt.prompt(); setHidden(true); }}>Installer</button>
      <button className="btn small" onClick={() => { setHidden(true); try { localStorage.setItem('samascore.install.dismissed', '1'); } catch {} }}>✕</button>
    </div>
  );
}
