'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { Fixture, Team } from '@/lib/supabase';
import { isConfigured } from '@/lib/supabase';
import { initials, isLive, isFinished, kickoffTime, minuteLabel, STATUS_LABEL, teamColor } from '@/lib/format';

export function TeamBadge({ team, size = 28 }: { team?: Team | null; size?: number }) {
  if (!team) return <span className="badge" style={{ width: size, height: size }} />;
  if (team.logo_url)
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={team.logo_url} alt="" width={size} height={size} className="badge-img" loading="lazy" />;
  return (
    <span className="badge" style={{ width: size, height: size, background: teamColor(team.name), fontSize: size * 0.38 }} aria-hidden>
      {team.code?.slice(0, 3) ?? initials(team.name)}
    </span>
  );
}

export function MatchRow({ f }: { f: Fixture }) {
  const live = isLive(f.status);
  const done = isFinished(f.status);
  const started = live || done;
  const homeWin = done && (f.home_goals ?? 0) > (f.away_goals ?? 0);
  const awayWin = done && (f.away_goals ?? 0) > (f.home_goals ?? 0);
  return (
    <Link href={`/match/?id=${f.id}`} className={`match-row ${live ? 'is-live' : ''}`}>
      <div className="match-time">
        {live ? <span className="live-min">{minuteLabel(f.status, f.elapsed, f.extra_time)}</span>
          : done ? <span className="muted">{STATUS_LABEL[f.status] || 'Fin'}</span>
          : ['PST', 'CANC', 'ABD'].includes(f.status) ? <span className="warn">{STATUS_LABEL[f.status]}</span>
          : <span>{kickoffTime(f.kickoff_at)}</span>}
      </div>
      <div className="match-teams">
        <div className={`team-line ${awayWin ? 'dim' : ''}`}><TeamBadge team={f.home} size={22} /><span className="team-name">{f.home?.name}</span></div>
        <div className={`team-line ${homeWin ? 'dim' : ''}`}><TeamBadge team={f.away} size={22} /><span className="team-name">{f.away?.name}</span></div>
      </div>
      <div className={`match-score ${live ? 'live' : ''}`}>
        <span>{started ? f.home_goals ?? 0 : ''}</span>
        <span>{started ? f.away_goals ?? 0 : ''}</span>
      </div>
    </Link>
  );
}

const NAV = [
  { href: '/', label: 'Scores', icon: '⚽' },
  { href: '/favoris/', label: 'Favoris', icon: '★' },
  { href: '/recherche/', label: 'Recherche', icon: '⌕' },
  { href: '/admin/', label: 'Admin', icon: '⚙' },
];

export function Shell({ title, children, back }: { title?: string; children: React.ReactNode; back?: boolean }) {
  const path = usePathname();
  return (
    <div className="app">
      <header className="topbar">
        {back ? (
          <button className="icon-btn" onClick={() => history.length > 1 ? history.back() : (location.href = '/')} aria-label="Retour">‹</button>
        ) : (
          <Link href="/" className="brand"><span className="brand-dot" />Sama<b>Score</b></Link>
        )}
        {title && <h1 className="topbar-title">{title}</h1>}
      </header>
      {!isConfigured && (
        <div className="banner warn">Base de données non configurée : ajoute NEXT_PUBLIC_SUPABASE_URL et NEXT_PUBLIC_SUPABASE_ANON_KEY dans Netlify.</div>
      )}
      <main className="content">{children}</main>
      <nav className="tabbar">
        {NAV.map((n) => {
          const active = n.href === '/' ? path === '/' : path?.startsWith(n.href.replace(/\/$/, ''));
          return (
            <Link key={n.href} href={n.href} className={active ? 'active' : ''}>
              <span className="tab-icon">{n.icon}</span>
              <span>{n.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

export function Skeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="card">
      {Array.from({ length: rows }).map((_, i) => <div key={i} className="skel" />)}
    </div>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="empty">{children}</div>;
}
