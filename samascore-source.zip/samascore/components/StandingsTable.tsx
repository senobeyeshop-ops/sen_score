'use client';
import Link from 'next/link';
import type { Standing } from '@/lib/supabase';
import { TeamBadge } from './ui';

export default function StandingsTable({ rows, highlight = [] }: { rows: Standing[]; highlight?: string[] }) {
  const groups = new Map<string, Standing[]>();
  for (const r of rows) {
    if (!groups.has(r.group_name)) groups.set(r.group_name, []);
    groups.get(r.group_name)!.push(r);
  }
  return (
    <>
      {[...groups.entries()].map(([g, list]) => (
        <section className="card" key={g}>
          {g && <div className="card-head">{g}</div>}
          <table className="standings">
            <thead>
              <tr><th>#</th><th style={{ textAlign: 'left' }}>Équipe</th><th>J</th><th>Diff</th><th>Pts</th><th>Forme</th></tr>
            </thead>
            <tbody>
              {list.map((r) => {
                const z = r.zone?.toLowerCase() ?? '';
                const zc = z.includes('relegation') || z.includes('relégation') ? 'z-down' : z ? 'z-up' : '';
                return (
                  <tr key={r.id} className={highlight.includes(r.team_id) ? 'hl' : ''}>
                    <td><span className={`rank ${zc}`} title={r.zone ?? ''}>{r.rank}</span></td>
                    <td className="team"><Link href={`/team/?id=${r.team_id}`}><TeamBadge team={r.team} size={20} />{r.team?.short_name ?? r.team?.name}</Link></td>
                    <td>{r.played}</td>
                    <td>{r.goals_for - r.goals_against > 0 ? '+' : ''}{r.goals_for - r.goals_against}</td>
                    <td><b>{r.points}</b></td>
                    <td>
                      <span className="form">
                        {(r.form ?? '').slice(-5).split('').map((c, i) => <i key={i} className={`f-${c}`}>{{ W: 'V', D: 'N', L: 'D' }[c] ?? c}</i>)}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </section>
      ))}
      <p className="note">Vert : qualification continentale · Rouge : relégation</p>
    </>
  );
}
