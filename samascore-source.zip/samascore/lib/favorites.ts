'use client';
import { useEffect, useState, useCallback } from 'react';

const KEY = 'samascore.favorites.v1';
type Favs = { teams: string[]; competitions: string[] };
const EMPTY: Favs = { teams: [], competitions: [] };

function read(): Favs {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? { ...EMPTY, ...JSON.parse(raw) } : EMPTY;
  } catch {
    return EMPTY;
  }
}

export function useFavorites() {
  const [favs, setFavs] = useState<Favs>(EMPTY);
  useEffect(() => {
    setFavs(read());
    const onChange = () => setFavs(read());
    window.addEventListener('samascore-favs', onChange);
    return () => window.removeEventListener('samascore-favs', onChange);
  }, []);

  const toggle = useCallback((kind: 'teams' | 'competitions', id: string) => {
    const cur = read();
    const list = cur[kind].includes(id) ? cur[kind].filter((x) => x !== id) : [...cur[kind], id];
    const next = { ...cur, [kind]: list };
    try { localStorage.setItem(KEY, JSON.stringify(next)); } catch {}
    setFavs(next);
    window.dispatchEvent(new Event('samascore-favs'));
  }, []);

  return { favs, toggle };
}
