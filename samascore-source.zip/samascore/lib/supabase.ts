import { createClient, SupabaseClient } from '@supabase/supabase-js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '';

export const isConfigured = Boolean(url && key);

let client: SupabaseClient | null = null;
export function sb(): SupabaseClient {
  if (!client) {
    client = createClient(url || 'https://example.supabase.co', key || 'missing', {
      auth: { persistSession: true, autoRefreshToken: true },
      realtime: { params: { eventsPerSecond: 5 } },
    });
  }
  return client;
}

export type Team = { id: string; name: string; short_name: string | null; code: string | null; logo_url: string | null; country_code: string | null; is_national: boolean };
export type Competition = { id: string; name: string; short_name: string | null; country_code: string | null; type: 'league' | 'cup'; logo_url: string | null; current_season: number | null; display_priority: number };
export type Fixture = {
  id: string; competition_id: string; season: number; round: string | null;
  home_team_id: string; away_team_id: string; kickoff_at: string; status: string;
  elapsed: number | null; extra_time: number | null;
  home_goals: number | null; away_goals: number | null;
  home_ht: number | null; away_ht: number | null; home_pen: number | null; away_pen: number | null;
  referee: string | null; tv_channels: string[]; lineups_confirmed: boolean; has_lineups: boolean;
  home?: Team; away?: Team; competition?: Competition;
};
export type FixtureEvent = {
  id: string; fixture_id: string; team_id: string | null; player_name: string | null; assist_name: string | null;
  minute: number; extra_minute: number | null; type: 'goal' | 'card' | 'subst' | 'var'; detail: string | null;
};
export type Standing = {
  id: string; team_id: string; rank: number; points: number; played: number; win: number; draw: number; lose: number;
  goals_for: number; goals_against: number; form: string | null; zone: string | null; group_name: string; team?: Team;
};

export const FIXTURE_SELECT =
  '*, home:teams!fixtures_home_team_id_fkey(*), away:teams!fixtures_away_team_id_fkey(*), competition:competitions(*)';
