export const TZ = 'Africa/Dakar';

export const LIVE = ['1H', 'HT', '2H', 'ET', 'BT', 'P', 'SUSP', 'INT', 'LIVE'];
export const FINISHED = ['FT', 'AET', 'PEN', 'AWD', 'WO'];
export const OFF = ['PST', 'CANC', 'ABD'];

export const isLive = (s: string) => LIVE.includes(s);
export const isFinished = (s: string) => FINISHED.includes(s);

export const STATUS_LABEL: Record<string, string> = {
  TBD: 'À fixer', NS: '', '1H': '1re MT', HT: 'Mi-temps', '2H': '2e MT', ET: 'Prolong.', BT: 'Pause', P: 'Tirs au but',
  SUSP: 'Suspendu', INT: 'Interrompu', FT: 'Terminé', AET: 'Ap. prol.', PEN: 'Ap. TAB', PST: 'Reporté', CANC: 'Annulé',
  ABD: 'Abandonné', AWD: 'Sur tapis vert', WO: 'Forfait', LIVE: 'En direct',
};

export function kickoffTime(iso: string) {
  return new Intl.DateTimeFormat('fr-FR', { timeZone: TZ, hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
}
export function longDate(iso: string) {
  return new Intl.DateTimeFormat('fr-FR', { timeZone: TZ, weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(iso));
}

/** 'YYYY-MM-DD' du jour à Dakar, décalé de `offset` jours */
export function dakarDay(offset = 0) {
  const d = new Date(Date.now() + offset * 86400000);
  return new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(d);
}
/** bornes UTC d'un jour Dakar (Dakar = UTC+0 toute l'année) */
export function dayRange(day: string) {
  return { from: `${day}T00:00:00Z`, to: `${day}T23:59:59.999Z` };
}
export function dayChip(offset: number, day: string) {
  if (offset === 0) return "Aujourd'hui";
  if (offset === -1) return 'Hier';
  if (offset === 1) return 'Demain';
  const d = new Date(`${day}T12:00:00Z`);
  return new Intl.DateTimeFormat('fr-FR', { timeZone: TZ, weekday: 'short', day: 'numeric' }).format(d);
}

export function minuteLabel(status: string, elapsed: number | null, extra: number | null) {
  if (status === 'HT') return 'MT';
  if (status === 'P') return 'TAB';
  if (!isLive(status)) return '';
  if (elapsed == null) return 'Live';
  return `${elapsed}${extra ? '+' + extra : ''}'`;
}

export function initials(name: string) {
  const parts = name.replace(/^(ASC|AS|US|FC|CA|SC)\s+/i, '').split(/\s+/);
  return (parts.length > 1 ? parts[0][0] + parts[1][0] : name.slice(0, 2)).toUpperCase();
}

/** couleur stable par équipe pour le badge sans logo */
export function teamColor(name: string) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  return `hsl(${h} 55% 38%)`;
}
