# SamaScore — scores de foot en direct (PWA)

Next.js (export statique) + Supabase (Postgres, Auth, Realtime). Déployé sur Netlify.

## Mise en route
1. Supabase → SQL Editor → coller `supabase/deploy.sql` → Run (schéma + démo).
2. Supabase → Database → Publications → vérifier que `supabase_realtime` contient `fixtures` et `fixture_events`.
3. Netlify → variables : `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` (clé publishable/anon, publique par nature).
4. Créer un compte sur /admin, puis dans l'éditeur SQL :
   `update profiles set role = 'admin' where id = (select id from auth.users where email = 'TON_EMAIL');`
5. Remettre la démo « en direct » à tout moment : `select public.seed_demo();`

## Développement
npm install · npm run dev · npm run build (sortie dans `out/`)
