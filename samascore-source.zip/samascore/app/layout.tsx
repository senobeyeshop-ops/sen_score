import type { Metadata, Viewport } from 'next';
import './globals.css';
import SwRegister from '@/components/SwRegister';

export const metadata: Metadata = {
  title: 'SamaScore — Scores de foot en direct',
  description: 'Scores en direct de la Ligue 1 Sénégal, des Lions, de la CAN et du football mondial.',
  manifest: '/manifest.webmanifest',
  icons: { icon: '/icon-192.png', apple: '/icon-192.png' },
  appleWebApp: { capable: true, title: 'SamaScore', statusBarStyle: 'black-translucent' },
};
export const viewport: Viewport = { themeColor: '#0b1410', width: 'device-width', initialScale: 1, viewportFit: 'cover' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        {children}
        <SwRegister />
      </body>
    </html>
  );
}
