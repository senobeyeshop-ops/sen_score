'use client';
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { sb, isConfigured, FIXTURE_SELECT, type Fixture } from '@/lib/supabase';
import { dakarDay, dayChip, dayRange, isLive } from '@/lib/format';
import { useFavorites } from '@/lib/favorites';
import { Shell, MatchRow, Skeleton, Empty } from '@/components/ui';
import InstallPrompt from '@/components/InstallPrompt';

const OFFSETS = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7];

export default function Home() {
  const [offset, setOffset] = useState(0);
  const [liveOnly, setLiveOnly] = useState(false);
  const [fixtures, setFixtures] = useState<Fixture[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { favs } = useFavorites();
  const day = dakarDay(offset);

  useEffect(() => {
    if (!isConfigured) { setFixtures([]); return; }
    let alive = true;
    setFixtures(null);
    const { from, to } = dayRange(day);
    sb().from('fixtures').select(FIXTURE_SELECT).gte('kickoff_at', from).lte('kickoff_at', to).order('kickoff_at')
      .then(({ data, error }) => {
        if (!alive) return;
        if (error) setError(error.message); else { setError(null); setFixtures((data ?? []) as Fixture[]); }
      });

    // temps réel : on fusionne score / minute / statut sans recharger
    const ch = sb().channel(`day-${day}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'fixtures' }, (p) => {
        const row = p.new as Fixture;
        setFixtures((cur) => cur?.map((f) => (f.id === row.id ? { ...f, ...row, home: f.home, away: f.away, competition: f.competition } : f)) ?? cur);
      })
      .subscribe();
    return () => { alive = false; sb().removeChannel(ch); };
  }, [day]);

  const visible = useMemo(() => (fixtures ?? []).filter((f) => !liveOnly || isLive(f.status)), [fixtures, liveOnly]);
  const liveCount = (fixtures ?? []).filter((f) => isLive(f.status)).length;

  const mine = visible.filter((f) => favs.teams.includes(f.home_team_id) || favs.teams.includes(f.away_team_id));

  const groups = useMemo(() => {
    const m = new Map<string, Fixture[]>();
    for (const f of visible) {
      const k = f.competition_id;
      if (!m.has(k)) m.set(k, []);
      m.get(k)!.push(f);
    }
    return [...m.values()].sort((a, b) => {
      const fa = favs.competitions.includes(a[0].competition_id) ? 0 : 1;
      const fb = favs.competitions.includes(b[0].competition_id) ? 0 : 1;
      return fa - fb || (a[0].competition?.display_priority ?? 1000) - (b[0].competition?.display_priority ?? 1000);
    });
  }, [visible, favs.competitions]);

  return (
    <Shell>
      <div className="chips" role="tablist" aria-label="Date">
        <button className={`chip live ${liveOnly ? 'active' : ''}`} onClick={() => setLiveOnly((v) => !v)}>
          ● En direct{liveCount ? ` (${liveCount})` : ''}
        </button>
        {OFFSETS.map((o) => (
          <button key={o} className={`chip ${o === offset ? 'active' : ''}`} onClick={() => setOffset(o)}>
            {dayChip(o, dakarDay(o))}
          </button>
        ))}
      </div>

      <InstallPrompt />

      {error && <div className="card card-body warn">Erreur : {error}</div>}
      {fixtures === null ? <Skeleton /> : (
        <>
          {mine.length > 0 && (
            <section className="card">
              <div className="card-head">★ Mes équipes</div>
              {mine.map((f) => <MatchRow key={f.id} f={f} />)}
            </section>
          )}
          {groups.length === 0 && (
            <Empty>{liveOnly ? 'Aucun match en direct pour le moment.' : 'Aucun match ce jour-là.'}</Empty>
          )}
          {groups.map((g) => {
            const c = g[0].competition;
            return (
              <section className="card" key={g[0].competition_id}>
                <Link href={`/competition/?id=${g[0].competition_id}`} className="card-head">
                  <span>{c?.name}</span>
                  <span className="sub">{c?.country_code === 'WORLD' ? 'International' : c?.country_code}</span>
                  <span className="spacer" />
                  <span className="sub">›</span>
                </Link>
                {g.map((f) => <MatchRow key={f.id} f={f} />)}
              </section>
            );
          })}
        </>
      )}
    </Shell>
  );
}
