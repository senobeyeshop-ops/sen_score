'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { sb, isConfigured, FIXTURE_SELECT, type Competition, type Fixture, type Team } from '@/lib/supabase';
import { isFinished, isLive } from '@/lib/format';
import { useFavorites } from '@/lib/favorites';
import { Shell, MatchRow, Empty, TeamBadge } from '@/components/ui';

export default function Favoris() {
  const { favs, toggle } = useFavorites();
  const [teams, setTeams] = useState<Team[]>([]);
  const [comps, setComps] = useState<Competition[]>([]);
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [suggest, setSuggest] = useState<Team[]>([]);

  useEffect(() => {
    if (!isConfigured) return;
    if (favs.teams.length) {
      sb().from('teams').select('*').in('id', favs.teams).then(({ data }) => setTeams((data ?? []) as Team[]));
      const ids = favs.teams.join(',');
      const from = new Date(Date.now() - 3 * 86400000).toISOString();
      const to = new Date(Date.now() + 10 * 86400000).toISOString();
      sb().from('fixtures').select(FIXTURE_SELECT).or(`home_team_id.in.(${ids}),away_team_id.in.(${ids})`)
        .gte('kickoff_at', from).lte('kickoff_at', to).order('kickoff_at')
        .then(({ data }) => setFixtures((data ?? []) as Fixture[]));
    } else { setTeams([]); setFixtures([]); }
    if (favs.competitions.length)
      sb().from('competitions').select('*').in('id', favs.competitions).then(({ data }) => setComps((data ?? []) as Competition[]));
    else setComps([]);
    // suggestions pour l'onboarding : Lions + clubs sénégalais
    sb().from('teams').select('*').eq('country_code', 'SN').order('is_national', { ascending: false }).order('name').limit(12)
      .then(({ data }) => setSuggest((data ?? []) as Team[]));
  }, [favs.teams, favs.competitions]);

  const live = fixtures.filter((f) => isLive(f.status));
  const next = fixtures.filter((f) => !isLive(f.status) && !isFinished(f.status));
  const done = fixtures.filter((f) => isFinished(f.status)).reverse();

  return (
    <Shell title="Mes favoris">
      {favs.teams.length === 0 && (
        <section className="card">
          <div className="card-head">Choisis tes équipes</div>
          <div className="card-body note">Touche une équipe pour la suivre. Ses matchs apparaîtront en haut de l&apos;accueil.</div>
          {suggest.map((t) => (
            <button key={t.id} className="list-link" style={{ width: '100%', background: 'none', border: 0, borderTop: '1px solid var(--line)' }} onClick={() => toggle('teams', t.id)}>
              <TeamBadge team={t} size={26} />{t.name}<span className="kind">☆ Suivre</span>
            </button>
          ))}
        </section>
      )}
      {live.length > 0 && <section className="card"><div className="card-head" style={{ color: 'var(--live)' }}>● En direct</div>{live.map((f) => <MatchRow key={f.id} f={f} />)}</section>}
      {next.length > 0 && <section className="card"><div className="card-head">À venir</div>{next.map((f) => <MatchRow key={f.id} f={f} />)}</section>}
      {done.length > 0 && <section className="card"><div className="card-head">Résultats récents</div>{done.map((f) => <MatchRow key={f.id} f={f} />)}</section>}
      {favs.teams.length > 0 && !fixtures.length && <Empty>Pas de match de tes équipes dans les 10 prochains jours.</Empty>}

      {(teams.length > 0 || comps.length > 0) && (
        <section className="card">
          <div className="card-head">Suivis</div>
          {teams.map((t) => (
            <div className="list-link" key={t.id}>
              <Link href={`/team/?id=${t.id}`} className="row"><TeamBadge team={t} size={24} />{t.name}</Link>
              <button className="star on" style={{ marginLeft: 'auto' }} onClick={() => toggle('teams', t.id)} aria-label="Ne plus suivre">★</button>
            </div>
          ))}
          {comps.map((c) => (
            <div className="list-link" key={c.id}>
              <Link href={`/competition/?id=${c.id}`}>🏆 {c.name}</Link>
              <button className="star on" style={{ marginLeft: 'auto' }} onClick={() => toggle('competitions', c.id)} aria-label="Ne plus suivre">★</button>
            </div>
          ))}
        </section>
      )}
    </Shell>
  );
}
