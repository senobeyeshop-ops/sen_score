'use client';
import { Suspense, useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { sb, isConfigured, FIXTURE_SELECT, type Fixture, type FixtureEvent, type Standing } from '@/lib/supabase';
import { isLive, isFinished, kickoffTime, longDate, minuteLabel, STATUS_LABEL, teamColor } from '@/lib/format';
import { Shell, TeamBadge, Skeleton, Empty } from '@/components/ui';
import StandingsTable from '@/components/StandingsTable';

type LineupPlayer = { id: string; player_name: string; shirt_number: number | null; position: string | null; grid: string | null; is_starter: boolean; sort_order: number };
type Lineup = { id: string; team_id: string; formation: string | null; coach_name: string | null; is_confirmed: boolean; lineup_players: LineupPlayer[] };
type Stats = { team_id: string; stats: Record<string, string | number | null> };

const STAT_ORDER: [string, string][] = [
  ['Ball Possession', 'Possession'], ['expected_goals', 'xG'], ['Total Shots', 'Tirs'], ['Shots on Goal', 'Tirs cadrés'],
  ['Corner Kicks', 'Corners'], ['Fouls', 'Fautes'], ['Offsides', 'Hors-jeu'], ['Yellow Cards', 'Cartons jaunes'],
  ['Red Cards', 'Cartons rouges'], ['Goalkeeper Saves', 'Arrêts'], ['Passes %', 'Passes réussies'],
];

function MatchInner() {
  const id = useSearchParams().get('id') ?? '';
  const [f, setF] = useState<Fixture | null>(null);
  const [events, setEvents] = useState<FixtureEvent[]>([]);
  const [lineups, setLineups] = useState<Lineup[]>([]);
  const [stats, setStats] = useState<Stats[]>([]);
  const [standings, setStandings] = useState<Standing[]>([]);
  const [tab, setTab] = useState<'resume' | 'compos' | 'stats' | 'classement'>('resume');
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!id || !isConfigured) return;
    const c = sb();
    const loadEvents = () =>
      c.from('fixture_events').select('*').eq('fixture_id', id).order('minute').order('extra_minute', { nullsFirst: true })
        .then(({ data }) => setEvents((data ?? []) as FixtureEvent[]));
    c.from('fixtures').select(FIXTURE_SELECT).eq('id', id).maybeSingle().then(({ data }) => {
      if (!data) { setNotFound(true); return; }
      const fx = data as Fixture;
      setF(fx);
      c.from('standings').select('*, team:teams(*)').eq('competition_id', fx.competition_id).eq('season', fx.season).order('group_name').order('rank')
        .then(({ data }) => setStandings((data ?? []) as Standing[]));
    });
    loadEvents();
    c.from('fixture_lineups').select('*, lineup_players(*)').eq('fixture_id', id).then(({ data }) => setLineups((data ?? []) as Lineup[]));
    c.from('fixture_stats').select('team_id, stats').eq('fixture_id', id).then(({ data }) => setStats((data ?? []) as Stats[]));

    const ch = c.channel(`match-${id}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'fixtures', filter: `id=eq.${id}` }, (p) =>
        setF((cur) => (cur ? { ...cur, ...(p.new as Fixture), home: cur.home, away: cur.away, competition: cur.competition } : cur)))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'fixture_events', filter: `fixture_id=eq.${id}` }, () => loadEvents())
      .subscribe();
    return () => { c.removeChannel(ch); };
  }, [id]);

  if (notFound) return <Shell back title="Match"><Empty>Match introuvable.</Empty></Shell>;
  if (!f) return <Shell back title="Match"><Skeleton rows={3} /></Shell>;

  const live = isLive(f.status);
  const started = live || isFinished(f.status);

  const share = async () => {
    const text = `${f.home?.name} ${started ? `${f.home_goals}-${f.away_goals}` : 'vs'} ${f.away?.name} — suis le match sur SamaScore`;
    const url = location.href;
    if (navigator.share) { try { await navigator.share({ text, url }); } catch {} }
    else window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`, '_blank');
  };

  return (
    <Shell back title={`${f.home?.short_name ?? f.home?.name} – ${f.away?.short_name ?? f.away?.name}`}>
      <section className="hero">
        <Link href={`/competition/?id=${f.competition_id}`} className="hero-comp" style={{ display: 'block' }}>
          {f.competition?.name}{f.round ? ` · ${f.round}` : ''}
        </Link>
        <div className="hero-grid">
          <Link href={`/team/?id=${f.home_team_id}`} className="hero-team"><TeamBadge team={f.home} size={56} />{f.home?.name}</Link>
          <div>
            <div className="hero-score">{started ? `${f.home_goals ?? 0} - ${f.away_goals ?? 0}` : kickoffTime(f.kickoff_at)}</div>
            <div className={`hero-status ${live ? 'live' : ''}`}>
              {live ? minuteLabel(f.status, f.elapsed, f.extra_time) : STATUS_LABEL[f.status] || longDate(f.kickoff_at)}
            </div>
            {f.home_pen != null && <div className="hero-status">TAB {f.home_pen}-{f.away_pen}</div>}
          </div>
          <Link href={`/team/?id=${f.away_team_id}`} className="hero-team"><TeamBadge team={f.away} size={56} />{f.away?.name}</Link>
        </div>
        <div className="hero-meta">
          {f.home_ht != null && started && <>MT {f.home_ht}-{f.away_ht} · </>}
          {longDate(f.kickoff_at)}
          {f.tv_channels?.length ? <> · 📺 {f.tv_channels.join(', ')}</> : null}
        </div>
        <div className="row" style={{ justifyContent: 'center', marginTop: 12 }}>
          <button className="btn small" onClick={share}>Partager sur WhatsApp</button>
        </div>
      </section>

      <div className="tabs">
        {(['resume', 'compos', 'stats', 'classement'] as const).map((t) => (
          <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>
            {{ resume: 'Résumé', compos: 'Compos', stats: 'Stats', classement: 'Classement' }[t]}
          </button>
        ))}
      </div>

      {tab === 'resume' && <Timeline f={f} events={events} />}
      {tab === 'compos' && <Lineups f={f} lineups={lineups} />}
      {tab === 'stats' && <StatsView f={f} stats={stats} />}
      {tab === 'classement' && (standings.length
        ? <StandingsTable rows={standings} highlight={[f.home_team_id, f.away_team_id]} />
        : <Empty>Pas de classement pour cette compétition.</Empty>)}
    </Shell>
  );
}

function evIcon(e: FixtureEvent) {
  if (e.type === 'goal') return e.detail === 'Missed Penalty' ? '❌' : '⚽';
  if (e.type === 'card') return <span className="ic-card" style={{ background: e.detail === 'Red Card' || e.detail === 'Second Yellow card' ? '#ff4d4f' : '#f5c518' }} />;
  if (e.type === 'subst') return '⇄';
  return '📺';
}
function evText(e: FixtureEvent) {
  const extra = e.type === 'goal' && e.detail === 'Own Goal' ? ' (csc)' : e.type === 'goal' && e.detail === 'Penalty' ? ' (pén.)' : '';
  if (e.type === 'subst') return <span>{e.assist_name} <span className="ev-sub">↔ {e.player_name}</span></span>;
  return (
    <span>
      {e.player_name}{extra}
      {e.assist_name && e.type === 'goal' && <span className="ev-sub"> · passe {e.assist_name}</span>}
      {e.type === 'var' && <span className="ev-sub"> · {e.detail}</span>}
    </span>
  );
}

function Timeline({ f, events }: { f: Fixture; events: FixtureEvent[] }) {
  if (!events.length) return <Empty>{f.status === 'NS' ? 'Le match n\'a pas commencé.' : 'Aucun événement pour le moment.'}</Empty>;
  return (
    <section className="card timeline">
      {[...events].reverse().map((e) => {
        const home = e.team_id === f.home_team_id;
        const content = <>{evIcon(e)} {evText(e)}</>;
        return (
          <div className="ev" key={e.id}>
            <div className="ev-side">{home ? content : null}</div>
            <div className="ev-min">{e.minute}{e.extra_minute ? `+${e.extra_minute}` : ''}&apos;</div>
            <div className="ev-side away">{!home ? content : null}</div>
          </div>
        );
      })}
    </section>
  );
}

function Lineups({ f, lineups }: { f: Fixture; lineups: Lineup[] }) {
  const [side, setSide] = useState<'home' | 'away'>('home');
  if (!lineups.length) return <Empty>Compositions pas encore disponibles (environ 1 h avant le coup d&apos;envoi).</Empty>;
  const teamId = side === 'home' ? f.home_team_id : f.away_team_id;
  const team = side === 'home' ? f.home : f.away;
  const lu = lineups.find((l) => l.team_id === teamId);
  const starters = (lu?.lineup_players ?? []).filter((p) => p.is_starter);
  const bench = (lu?.lineup_players ?? []).filter((p) => !p.is_starter).sort((a, b) => a.sort_order - b.sort_order);
  const rows = new Map<number, LineupPlayer[]>();
  for (const p of starters) {
    const r = Number(p.grid?.split(':')[0] ?? 1);
    if (!rows.has(r)) rows.set(r, []);
    rows.get(r)!.push(p);
  }
  const maxRow = Math.max(1, ...rows.keys());
  const color = team ? teamColor(team.name) : '#333';
  return (
    <>
      <div className="tabs">
        <button className={side === 'home' ? 'active' : ''} onClick={() => setSide('home')}>{f.home?.name}</button>
        <button className={side === 'away' ? 'active' : ''} onClick={() => setSide('away')}>{f.away?.name}</button>
      </div>
      {!lu ? <Empty>Composition non disponible.</Empty> : (
        <section className="card">
          <div className="card-head">
            <span>{lu.formation ?? '—'}</span>
            <span className="sub">{lu.is_confirmed ? 'Composition officielle' : 'Composition probable'}</span>
          </div>
          <div style={{ padding: 10 }}>
            <div className="pitch">
              {[...rows.entries()].map(([r, ps]) =>
                ps.sort((a, b) => Number(a.grid?.split(':')[1]) - Number(b.grid?.split(':')[1])).map((p, i) => {
                  const y = 90 - ((r - 1) / Math.max(1, maxRow - 1)) * 75;
                  const x = ((i + 1) / (ps.length + 1)) * 100;
                  return (
                    <div className="pl" key={p.id} style={{ left: `${x}%`, top: `${y}%` }}>
                      <span className="pl-num" style={{ background: color }}>{p.shirt_number ?? ''}</span>
                      <span className="pl-name">{p.player_name.split(' ').slice(-1)[0]}</span>
                    </div>
                  );
                }))}
            </div>
          </div>
          {lu.coach_name && <div className="bench"><span className="muted">Entraîneur</span> {lu.coach_name}</div>}
          {bench.length > 0 && (
            <div className="bench" style={{ flexDirection: 'column' }}>
              <span className="muted">Remplaçants</span>
              {bench.map((p) => <span key={p.id}>{p.shirt_number} · {p.player_name}</span>)}
            </div>
          )}
        </section>
      )}
    </>
  );
}

function num(v: unknown) {
  if (v == null) return 0;
  const n = parseFloat(String(v).replace('%', ''));
  return Number.isFinite(n) ? n : 0;
}

function StatsView({ f, stats }: { f: Fixture; stats: Stats[] }) {
  const h = stats.find((s) => s.team_id === f.home_team_id)?.stats ?? {};
  const a = stats.find((s) => s.team_id === f.away_team_id)?.stats ?? {};
  const rows = STAT_ORDER.filter(([k]) => h[k] != null || a[k] != null);
  if (!rows.length) return <Empty>Statistiques pas encore disponibles.</Empty>;
  return (
    <section className="card">
      {rows.map(([k, label]) => {
        const hv = num(h[k]), av = num(a[k]);
        const tot = hv + av || 1;
        return (
          <div className="stat" key={k}>
            <div className="stat-top"><b>{h[k] ?? 0}</b><span>{label}</span><b>{a[k] ?? 0}</b></div>
            <div className="stat-bars">
              <div style={{ flex: hv / tot, background: hv >= av ? 'var(--accent)' : 'var(--line)' }} />
              <div style={{ flex: av / tot, background: av > hv ? 'var(--gold)' : 'var(--line)' }} />
            </div>
          </div>
        );
      })}
    </section>
  );
}

export default function MatchPage() {
  return <Suspense fallback={<Shell back title="Match"><Skeleton rows={3} /></Shell>}><MatchInner /></Suspense>;
}
