'use client';
import { useCallback, useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { sb, isConfigured, FIXTURE_SELECT, type Competition, type Fixture, type Team } from '@/lib/supabase';
import { dakarDay, kickoffTime, STATUS_LABEL } from '@/lib/format';
import { Shell, Empty, TeamBadge } from '@/components/ui';

const STATUSES = ['NS', '1H', 'HT', '2H', 'ET', 'P', 'FT', 'AET', 'PEN', 'PST', 'CANC', 'SUSP'];

export default function Admin() {
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<string | null>(null);

  useEffect(() => {
    if (!isConfigured) return;
    sb().auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = sb().auth.onAuthStateChange((_e, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) { setRole(null); return; }
    sb().from('profiles').select('role').eq('id', session.user.id).maybeSingle().then(({ data }) => setRole(data?.role ?? 'user'));
  }, [session]);

  if (!session) return <Shell title="Admin"><Login /></Shell>;
  if (role === null) return <Shell title="Admin"><Empty>Chargement…</Empty></Shell>;
  if (role !== 'admin') {
    return (
      <Shell title="Admin">
        <section className="card card-body stack">
          <p>Connecté en tant que <b>{session.user.email}</b>, mais ce compte n&apos;est pas administrateur.</p>
          <p className="note">Pour le promouvoir, exécute dans l&apos;éditeur SQL de Supabase :<br />
            <code>update profiles set role = &apos;admin&apos; where id = &apos;{session.user.id}&apos;;</code></p>
          <button className="btn" onClick={() => sb().auth.signOut()}>Se déconnecter</button>
        </section>
      </Shell>
    );
  }
  return <Shell title="Admin — saisie des matchs"><Console email={session.user.email ?? ''} /></Shell>;
}

function Login() {
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const go = async (mode: 'in' | 'up') => {
    setBusy(true); setMsg(null);
    const r = mode === 'in'
      ? await sb().auth.signInWithPassword({ email, password: pw })
      : await sb().auth.signUp({ email, password: pw });
    setBusy(false);
    if (r.error) setMsg(r.error.message);
    else if (mode === 'up' && !r.data.session) setMsg('Compte créé. Confirme ton e-mail puis connecte-toi.');
  };
  return (
    <section className="card card-body stack">
      <p style={{ margin: 0 }}>Espace réservé à l&apos;équipe SamaScore pour saisir les matchs non couverts automatiquement (Ligue 1 Sénégal, navétanes…).</p>
      <label className="field">E-mail<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" /></label>
      <label className="field">Mot de passe<input type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" /></label>
      <div className="row">
        <button className="btn primary" disabled={busy} onClick={() => go('in')}>Se connecter</button>
        <button className="btn" disabled={busy} onClick={() => go('up')}>Créer un compte</button>
      </div>
      {msg && <p className="warn" style={{ margin: 0 }}>{msg}</p>}
    </section>
  );
}

function Console({ email }: { email: string }) {
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [comps, setComps] = useState<Competition[]>([]);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(() => {
    sb().from('fixtures').select(FIXTURE_SELECT)
      .gte('kickoff_at', `${dakarDay(-1)}T00:00:00Z`).lte('kickoff_at', `${dakarDay(2)}T23:59:59Z`).order('kickoff_at')
      .then(({ data, error }) => { if (error) setErr(error.message); setFixtures((data ?? []) as Fixture[]); });
  }, []);

  useEffect(() => {
    load();
    sb().from('teams').select('*').order('name').then(({ data }) => setTeams((data ?? []) as Team[]));
    sb().from('competitions').select('*').order('display_priority').then(({ data }) => setComps((data ?? []) as Competition[]));
  }, [load]);

  const run = async (p: PromiseLike<{ error: { message: string } | null }>) => {
    const { error } = await p;
    if (error) setErr(error.message); else { setErr(null); load(); }
  };

  return (
    <>
      <div className="row note"><span>Connecté : {email}</span><button className="btn small" style={{ marginLeft: 'auto' }} onClick={() => sb().auth.signOut()}>Déconnexion</button></div>
      {err && <div className="card card-body warn">Erreur : {err}</div>}
      <NewFixture teams={teams} comps={comps} onDone={load} setErr={setErr} />
      {fixtures.length === 0 && <Empty>Aucun match d&apos;hier à après-demain.</Empty>}
      {fixtures.map((f) => <FixtureEditor key={f.id} f={f} run={run} />)}
      <NewTeam onDone={() => sb().from('teams').select('*').order('name').then(({ data }) => setTeams((data ?? []) as Team[]))} setErr={setErr} />
    </>
  );
}

function FixtureEditor({ f, run }: { f: Fixture; run: (p: PromiseLike<{ error: { message: string } | null }>) => Promise<void> }) {
  const [minute, setMinute] = useState<string>(String(f.elapsed ?? ''));
  useEffect(() => setMinute(String(f.elapsed ?? '')), [f.elapsed]);

  const setStatus = (status: string) => {
    const patch: Record<string, unknown> = { status };
    if (status === '1H') { patch.elapsed = 1; patch.home_goals = f.home_goals ?? 0; patch.away_goals = f.away_goals ?? 0; }
    if (status === 'HT') { patch.elapsed = 45; patch.home_ht = f.home_goals ?? 0; patch.away_ht = f.away_goals ?? 0; }
    if (status === '2H') patch.elapsed = 46;
    if (status === 'FT') patch.elapsed = 90;
    return run(sb().from('fixtures').update(patch).eq('id', f.id));
  };

  const addEvent = async (side: 'home' | 'away', type: 'goal' | 'card', detail: string) => {
    const who = window.prompt(type === 'goal' ? 'Buteur (facultatif)' : 'Joueur averti (facultatif)') ?? '';
    const teamId = side === 'home' ? f.home_team_id : f.away_team_id;
    const m = Number(minute) || f.elapsed || 0;
    await run(sb().from('fixture_events').insert({
      fixture_id: f.id, team_id: teamId, player_name: who || null, minute: m, type, detail,
      dedup_key: `manual-${crypto.randomUUID()}`,
    }));
    if (type === 'goal') {
      const key = side === 'home' ? 'home_goals' : 'away_goals';
      await run(sb().from('fixtures').update({ [key]: (f[key] ?? 0) + 1, elapsed: m }).eq('id', f.id));
    }
  };

  return (
    <section className="card">
      <div className="card-head">
        <span>{f.competition?.short_name ?? f.competition?.name}</span>
        <span className="sub">{kickoffTime(f.kickoff_at)} · {STATUS_LABEL[f.status] || 'À venir'}</span>
      </div>
      <div className="card-body stack">
        <div className="row" style={{ justifyContent: 'space-between', fontWeight: 600 }}>
          <span className="row"><TeamBadge team={f.home} size={22} />{f.home?.name}</span>
          <span style={{ fontSize: 22 }}>{f.home_goals ?? '-'} : {f.away_goals ?? '-'}</span>
          <span className="row">{f.away?.name}<TeamBadge team={f.away} size={22} /></span>
        </div>
        <div className="row">
          <select value={f.status} onChange={(e) => setStatus(e.target.value)} style={{ flex: 1 }} aria-label="Statut">
            {STATUSES.map((s) => <option key={s} value={s}>{s} {STATUS_LABEL[s] ? `— ${STATUS_LABEL[s]}` : '— à venir'}</option>)}
          </select>
          <input value={minute} onChange={(e) => setMinute(e.target.value)} inputMode="numeric" style={{ width: 70 }} aria-label="Minute" />
          <button className="btn small" onClick={() => run(sb().from('fixtures').update({ elapsed: Number(minute) || null }).eq('id', f.id))}>Minute</button>
        </div>
        <div className="row">
          <button className="btn small primary" onClick={() => addEvent('home', 'goal', 'Normal Goal')}>⚽ But dom.</button>
          <button className="btn small primary" onClick={() => addEvent('away', 'goal', 'Normal Goal')}>⚽ But ext.</button>
          <button className="btn small" onClick={() => addEvent('home', 'card', 'Yellow Card')}>🟨 dom.</button>
          <button className="btn small" onClick={() => addEvent('away', 'card', 'Yellow Card')}>🟨 ext.</button>
          <button className="btn small danger" onClick={() => addEvent('home', 'card', 'Red Card')}>🟥 dom.</button>
          <button className="btn small danger" onClick={() => addEvent('away', 'card', 'Red Card')}>🟥 ext.</button>
        </div>
      </div>
    </section>
  );
}

function NewFixture({ teams, comps, onDone, setErr }: { teams: Team[]; comps: Competition[]; onDone: () => void; setErr: (s: string | null) => void }) {
  const [open, setOpen] = useState(false);
  const [comp, setComp] = useState('');
  const [home, setHome] = useState('');
  const [away, setAway] = useState('');
  const [when, setWhen] = useState(`${dakarDay(0)}T16:30`);
  const [round, setRound] = useState('');
  const save = async () => {
    const c = comps.find((x) => x.id === comp);
    const { error } = await sb().from('fixtures').insert({
      provider: 'manual', competition_id: comp, season: c?.current_season ?? new Date().getFullYear(),
      home_team_id: home, away_team_id: away, kickoff_at: new Date(`${when}:00Z`).toISOString(), round: round || null,
    });
    if (error) setErr(error.message); else { setErr(null); setOpen(false); onDone(); }
  };
  if (!open) return <button className="btn primary" onClick={() => setOpen(true)}>+ Nouveau match</button>;
  return (
    <section className="card card-body stack">
      <label className="field">Compétition<select value={comp} onChange={(e) => setComp(e.target.value)}><option value="">—</option>{comps.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <label className="field">Domicile<select value={home} onChange={(e) => setHome(e.target.value)}><option value="">—</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
      <label className="field">Extérieur<select value={away} onChange={(e) => setAway(e.target.value)}><option value="">—</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
      <label className="field">Coup d&apos;envoi (heure de Dakar)<input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} /></label>
      <label className="field">Journée / tour<input value={round} onChange={(e) => setRound(e.target.value)} placeholder="Journée 8" /></label>
      <div className="row">
        <button className="btn primary" disabled={!comp || !home || !away || home === away} onClick={save}>Créer</button>
        <button className="btn" onClick={() => setOpen(false)}>Annuler</button>
      </div>
    </section>
  );
}

function NewTeam({ onDone, setErr }: { onDone: () => void; setErr: (s: string | null) => void }) {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const save = async () => {
    const { error } = await sb().from('teams').insert({ provider: 'manual', name, short_name: name, code: code.toUpperCase() || null, country_code: 'SN' });
    if (error) setErr(error.message); else { setName(''); setCode(''); onDone(); }
  };
  return (
    <section className="card card-body stack">
      <b>Ajouter une équipe (Sénégal)</b>
      <div className="row">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nom (ex. ASC Niarry Tally)" style={{ flex: 2 }} />
        <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Code" maxLength={3} style={{ flex: 1 }} />
        <button className="btn" disabled={name.length < 2} onClick={save}>Ajouter</button>
      </div>
    </section>
  );
}
