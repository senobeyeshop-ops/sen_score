'use client';
import { Suspense, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { sb, isConfigured, FIXTURE_SELECT, type Fixture, type Team } from '@/lib/supabase';
import { isFinished } from '@/lib/format';
import { useFavorites } from '@/lib/favorites';
import { Shell, MatchRow, Skeleton, Empty, TeamBadge } from '@/components/ui';

function Inner() {
  const id = useSearchParams().get('id') ?? '';
  const [t, setT] = useState<Team | null>(null);
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const { favs, toggle } = useFavorites();

  useEffect(() => {
    if (!id || !isConfigured) return;
    sb().from('teams').select('*').eq('id', id).maybeSingle().then(({ data }) => setT(data as Team));
    sb().from('fixtures').select(FIXTURE_SELECT).or(`home_team_id.eq.${id},away_team_id.eq.${id}`).order('kickoff_at')
      .then(({ data }) => setFixtures((data ?? []) as Fixture[]));
  }, [id]);

  if (!t) return <Shell back title="Équipe"><Skeleton /></Shell>;
  const fav = favs.teams.includes(t.id);
  const done = fixtures.filter((f) => isFinished(f.status)).reverse().slice(0, 10);
  const next = fixtures.filter((f) => !isFinished(f.status)).slice(0, 10);
  const form = done.slice(0, 5).map((f) => {
    const us = f.home_team_id === t.id ? f.home_goals ?? 0 : f.away_goals ?? 0;
    const them = f.home_team_id === t.id ? f.away_goals ?? 0 : f.home_goals ?? 0;
    return us > them ? 'W' : us === them ? 'D' : 'L';
  });

  return (
    <Shell back title={t.name}>
      <section className="hero" style={{ textAlign: 'center' }}>
        <div style={{ display: 'flex', justifyContent: 'center' }}><TeamBadge team={t} size={72} /></div>
        <h2 style={{ margin: '10px 0 4px' }}>{t.name}</h2>
        <div className="muted" style={{ fontSize: 13 }}>{t.is_national ? 'Équipe nationale' : 'Club'}{t.country_code ? ` · ${t.country_code}` : ''}</div>
        {form.length > 0 && (
          <div className="form" style={{ marginTop: 10 }}>
            {form.map((c, i) => <i key={i} className={`f-${c}`}>{{ W: 'V', D: 'N', L: 'D' }[c]}</i>)}
          </div>
        )}
        <div style={{ marginTop: 12 }}>
          <button className={`btn ${fav ? '' : 'primary'}`} onClick={() => toggle('teams', t.id)}>
            {fav ? '★ Suivie' : '☆ Suivre cette équipe'}
          </button>
        </div>
      </section>
      <section className="card">
        <div className="card-head">Prochains matchs</div>
        {next.length ? next.map((f) => <MatchRow key={f.id} f={f} />) : <Empty>Aucun match prévu.</Empty>}
      </section>
      <section className="card">
        <div className="card-head">Derniers résultats</div>
        {done.length ? done.map((f) => <MatchRow key={f.id} f={f} />) : <Empty>Aucun résultat.</Empty>}
      </section>
    </Shell>
  );
}

export default function Page() {
  return <Suspense fallback={<Shell back><Skeleton /></Shell>}><Inner /></Suspense>;
}
