'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { sb, isConfigured } from '@/lib/supabase';
import { Shell, Empty, TeamBadge } from '@/components/ui';

type Hit = { kind: 'team' | 'competition' | 'player'; id: string; name: string; logo_url: string | null };

export default function Recherche() {
  const [q, setQ] = useState('');
  const [hits, setHits] = useState<Hit[] | null>(null);

  useEffect(() => {
    if (!isConfigured || q.trim().length < 2) { setHits(null); return; }
    const t = setTimeout(() => {
      sb().rpc('search_all', { q: q.trim(), lim: 25 }).then(({ data }) => setHits((data ?? []) as Hit[]));
    }, 250);
    return () => clearTimeout(t);
  }, [q]);

  const href = (h: Hit) => h.kind === 'team' ? `/team/?id=${h.id}` : h.kind === 'competition' ? `/competition/?id=${h.id}` : '#';
  const kind = { team: 'Équipe', competition: 'Compétition', player: 'Joueur' };

  return (
    <Shell title="Recherche">
      <input autoFocus placeholder="Équipe, compétition, joueur…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Rechercher" />
      {hits === null ? <Empty>Tape au moins 2 lettres : « Jaraaf », « Sénégal », « Ligue 1 »…</Empty>
        : hits.length === 0 ? <Empty>Aucun résultat pour « {q} ».</Empty>
        : (
          <section className="card">
            {hits.map((h) => (
              <Link key={h.kind + h.id} href={href(h)} className="list-link">
                {h.kind === 'competition' ? <span>🏆</span> : <TeamBadge team={{ id: h.id, name: h.name, logo_url: h.logo_url, code: null, short_name: null, country_code: null, is_national: false }} size={24} />}
                {h.name}
                <span className="kind">{kind[h.kind]}</span>
              </Link>
            ))}
          </section>
        )}
    </Shell>
  );
}
