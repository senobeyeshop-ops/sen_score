'use client';
import { Suspense, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { sb, isConfigured, FIXTURE_SELECT, type Competition, type Fixture, type Standing } from '@/lib/supabase';
import { isFinished, longDate } from '@/lib/format';
import { useFavorites } from '@/lib/favorites';
import { Shell, MatchRow, Skeleton, Empty } from '@/components/ui';
import StandingsTable from '@/components/StandingsTable';

function Inner() {
  const id = useSearchParams().get('id') ?? '';
  const [c, setC] = useState<Competition | null>(null);
  const [standings, setStandings] = useState<Standing[]>([]);
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [tab, setTab] = useState<'classement' | 'resultats' | 'calendrier'>('classement');
  const { favs, toggle } = useFavorites();

  useEffect(() => {
    if (!id || !isConfigured) return;
    sb().from('competitions').select('*').eq('id', id).maybeSingle().then(({ data }) => {
      const comp = data as Competition | null;
      setC(comp);
      if (!comp) return;
      sb().from('standings').select('*, team:teams(*)').eq('competition_id', id).eq('season', comp.current_season ?? 0).order('group_name').order('rank')
        .then(({ data }) => { setStandings((data ?? []) as Standing[]); if (!data?.length) setTab('calendrier'); });
    });
    sb().from('fixtures').select(FIXTURE_SELECT).eq('competition_id', id).order('kickoff_at')
      .then(({ data }) => setFixtures((data ?? []) as Fixture[]));
  }, [id]);

  if (!c) return <Shell back title="Compétition"><Skeleton /></Shell>;
  const fav = favs.competitions.includes(c.id);
  const results = fixtures.filter((f) => isFinished(f.status)).reverse();
  const upcoming = fixtures.filter((f) => !isFinished(f.status));
  const list = tab === 'resultats' ? results : upcoming;

  // regroupe par jour
  const byDay = new Map<string, Fixture[]>();
  for (const f of list) {
    const d = longDate(f.kickoff_at);
    if (!byDay.has(d)) byDay.set(d, []);
    byDay.get(d)!.push(f);
  }

  return (
    <Shell back title={c.name}>
      <div className="card card-head" style={{ borderRadius: 14 }}>
        <span>{c.name}</span><span className="sub">{c.current_season ? `${c.current_season}/${(c.current_season + 1) % 100}` : ''}</span>
        <span className="spacer" />
        <button className={`star ${fav ? 'on' : ''}`} onClick={() => toggle('competitions', c.id)} aria-label="Suivre">{fav ? '★' : '☆'}</button>
      </div>
      <div className="tabs">
        <button className={tab === 'classement' ? 'active' : ''} onClick={() => setTab('classement')}>Classement</button>
        <button className={tab === 'calendrier' ? 'active' : ''} onClick={() => setTab('calendrier')}>À venir</button>
        <button className={tab === 'resultats' ? 'active' : ''} onClick={() => setTab('resultats')}>Résultats</button>
      </div>
      {tab === 'classement' ? (standings.length ? <StandingsTable rows={standings} /> : <Empty>Pas de classement (compétition à élimination directe).</Empty>)
        : byDay.size === 0 ? <Empty>Aucun match.</Empty>
        : [...byDay.entries()].map(([d, fs]) => (
          <section className="card" key={d}>
            <div className="card-head" style={{ textTransform: 'capitalize' }}>{d}</div>
            {fs.map((f) => <MatchRow key={f.id} f={f} />)}
          </section>
        ))}
    </Shell>
  );
}

export default function Page() {
  return <Suspense fallback={<Shell back><Skeleton /></Shell>}><Inner /></Suspense>;
}
