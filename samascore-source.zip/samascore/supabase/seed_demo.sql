-- =====================================================================
-- SamaScore — données de démonstration
-- Matchs placés autour de l'heure actuelle : relance `select public.seed_demo();`
-- dans l'éditeur SQL pour remettre la démo « en direct » quand tu veux.
-- Joueurs et compositions fictifs. Ne touche jamais aux données non-démo.
-- =====================================================================
create or replace function public.seed_demo() returns text
language plpgsql security definer set search_path = public as $$
declare
  c_amical uuid; c_l1 uuid; c_caf uuid;
  t record; tid jsonb := '{}';
  f_live uuid; f_ht uuid; f_ft uuid; l_home uuid; l_away uuid;
  d0 timestamptz := date_trunc('day', now());
  n int := 0;
  names text[] := array['Diop','Ndiaye','Fall','Sarr','Gueye','Faye','Ba','Sow','Cissé','Mbaye','Seck','Diallo','Kane','Niang','Thiam','Camara'];
  firsts text[] := array['Moussa','Cheikh','Pape','Ibrahima','Mamadou','Lamine','Abdou','Ousmane','Aliou','Babacar','Serigne','Malick','Amadou','Saliou','Modou','Ismaïla'];
begin
  -- on repart de zéro pour la démo uniquement
  delete from competitions where is_demo;
  delete from teams where is_demo;

  insert into countries(code, name) values ('SN','Sénégal'),('MA','Maroc'),('EG','Égypte'),('WORLD','International')
  on conflict (code) do nothing;

  insert into competitions(provider, name, short_name, country_code, type, current_season, display_priority, is_demo)
  values ('manual','Matchs internationaux','Internationaux','WORLD','cup',2026,5,true) returning id into c_amical;
  insert into competitions(provider, name, short_name, country_code, type, current_season, display_priority, is_demo)
  values ('manual','Ligue 1 Sénégal','Ligue 1 SN','SN','league',2026,10,true) returning id into c_l1;
  insert into competitions(provider, name, short_name, country_code, type, current_season, display_priority, is_demo)
  values ('manual','Ligue des champions CAF','LdC CAF','WORLD','cup',2026,20,true) returning id into c_caf;

  for t in select * from (values
    ('Sénégal','SEN','SN',true),('Maroc','MAR','MA',true),
    ('ASC Jaraaf','JAR','SN',false),('Teungueth FC','TFC','SN',false),('Génération Foot','GFO','SN',false),
    ('Casa Sports','CAS','SN',false),('AS Pikine','ASP','SN',false),('US Gorée','USG','SN',false),
    ('Guédiawaye FC','GFC','SN',false),('Dakar Sacré-Cœur','DSC','SN',false),('Stade de Mbour','SDM','SN',false),
    ('Jamono Fatick','JAM','SN',false),('Wally Daan','WAL','SN',false),('Linguère de Saint-Louis','LSL','SN',false),
    ('Al Ahly','AHL','EG',false)) v(name, code, cc, nat)
  loop
    insert into teams(provider, name, short_name, code, country_code, is_national, is_demo)
    values ('manual', t.name, t.name, t.code, t.cc, t.nat, true)
    returning jsonb_set(tid, array[t.code], to_jsonb(id)) into tid;
  end loop;

  -- ---------- matchs ----------
  -- Sénégal – Maroc : en direct, 67e
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at, status, elapsed,
                       home_goals, away_goals, home_ht, away_ht, referee, tv_channels, has_lineups, lineups_confirmed)
  values ('manual', c_amical, 2026, 'Match amical', (tid->>'SEN')::uuid, (tid->>'MAR')::uuid, now() - interval '82 minutes',
          '2H', 67, 1, 1, 1, 0, 'Arbitre de démonstration', '{RTS 1}', true, true) returning id into f_live;

  -- Jaraaf – Teungueth : mi-temps
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at, status, elapsed,
                       home_goals, away_goals, home_ht, away_ht)
  values ('manual', c_l1, 2026, 'Journée 7', (tid->>'JAR')::uuid, (tid->>'TFC')::uuid, now() - interval '50 minutes',
          'HT', 45, 0, 1, 0, 1) returning id into f_ht;

  -- Génération Foot – Casa : terminé
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at, status, elapsed,
                       home_goals, away_goals, home_ht, away_ht)
  values ('manual', c_l1, 2026, 'Journée 7', (tid->>'GFO')::uuid, (tid->>'CAS')::uuid, now() - interval '3 hours',
          'FT', 90, 2, 1, 1, 1) returning id into f_ft;

  -- à venir aujourd'hui, demain, et la suite
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at) values
    ('manual', c_l1, 2026, 'Journée 7', (tid->>'ASP')::uuid, (tid->>'USG')::uuid, now() + interval '2 hours'),
    ('manual', c_l1, 2026, 'Journée 7', (tid->>'GFC')::uuid, (tid->>'DSC')::uuid, now() + interval '4 hours'),
    ('manual', c_l1, 2026, 'Journée 7', (tid->>'SDM')::uuid, (tid->>'JAM')::uuid, d0 + interval '1 day 16 hours 30 minutes'),
    ('manual', c_l1, 2026, 'Journée 7', (tid->>'WAL')::uuid, (tid->>'LSL')::uuid, d0 + interval '1 day 19 hours'),
    ('manual', c_caf, 2026, 'Phase de groupes - J3', (tid->>'AHL')::uuid, (tid->>'JAR')::uuid, d0 + interval '2 days 17 hours'),
    ('manual', c_l1, 2026, 'Journée 8', (tid->>'TFC')::uuid, (tid->>'GFO')::uuid, d0 + interval '6 days 16 hours 30 minutes'),
    ('manual', c_l1, 2026, 'Journée 8', (tid->>'CAS')::uuid, (tid->>'JAR')::uuid, d0 + interval '6 days 19 hours');

  -- résultats d'hier et d'avant-hier
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at, status, elapsed, home_goals, away_goals, home_ht, away_ht) values
    ('manual', c_l1, 2026, 'Journée 6', (tid->>'TFC')::uuid, (tid->>'ASP')::uuid, d0 - interval '1 day' + interval '16 hours 30 minutes', 'FT', 90, 3, 0, 1, 0),
    ('manual', c_l1, 2026, 'Journée 6', (tid->>'USG')::uuid, (tid->>'JAR')::uuid, d0 - interval '1 day' + interval '19 hours', 'FT', 90, 1, 1, 0, 1),
    ('manual', c_l1, 2026, 'Journée 6', (tid->>'CAS')::uuid, (tid->>'GFC')::uuid, d0 - interval '2 days' + interval '16 hours 30 minutes', 'FT', 90, 2, 0, 2, 0),
    ('manual', c_l1, 2026, 'Journée 6', (tid->>'DSC')::uuid, (tid->>'GFO')::uuid, d0 - interval '2 days' + interval '19 hours', 'FT', 90, 0, 2, 0, 1);

  -- ---------- événements ----------
  insert into fixture_events(fixture_id, team_id, player_name, assist_name, minute, extra_minute, type, detail, dedup_key) values
    (f_live, (tid->>'SEN')::uuid, 'Cheikh Diop', 'Pape Sarr', 23, null, 'goal', 'Normal Goal', 'demo-1'),
    (f_live, (tid->>'MAR')::uuid, 'Y. Alaoui', null, 31, null, 'card', 'Yellow Card', 'demo-2'),
    (f_live, (tid->>'SEN')::uuid, 'Ibrahima Fall', null, 44, 2, 'card', 'Yellow Card', 'demo-3'),
    (f_live, (tid->>'MAR')::uuid, 'Y. Alaoui', 'H. Bennani', 58, null, 'goal', 'Penalty', 'demo-4'),
    (f_live, (tid->>'SEN')::uuid, 'Ousmane Ba', 'Moussa Gueye', 63, null, 'subst', 'Substitution 1', 'demo-5'),
    (f_ht,   (tid->>'TFC')::uuid, 'Lamine Seck', 'Abdou Faye', 38, null, 'goal', 'Normal Goal', 'demo-6'),
    (f_ft,   (tid->>'GFO')::uuid, 'Malick Thiam', null, 12, null, 'goal', 'Normal Goal', 'demo-7'),
    (f_ft,   (tid->>'CAS')::uuid, 'Saliou Kane', null, 40, null, 'goal', 'Penalty', 'demo-8'),
    (f_ft,   (tid->>'CAS')::uuid, 'Modou Niang', null, 71, null, 'card', 'Red Card', 'demo-9'),
    (f_ft,   (tid->>'GFO')::uuid, 'Malick Thiam', 'Aliou Camara', 88, null, 'goal', 'Normal Goal', 'demo-10');

  -- ---------- compositions (fictives) du match en direct ----------
  insert into fixture_lineups(fixture_id, team_id, formation, coach_name, is_confirmed)
  values (f_live, (tid->>'SEN')::uuid, '4-3-3', 'Sélectionneur (démo)', true) returning id into l_home;
  insert into fixture_lineups(fixture_id, team_id, formation, coach_name, is_confirmed)
  values (f_live, (tid->>'MAR')::uuid, '4-2-3-1', 'Sélectionneur (démo)', true) returning id into l_away;

  insert into lineup_players(lineup_id, player_name, shirt_number, position, grid, is_starter, sort_order)
  select l_home, firsts[i] || ' ' || names[i], i, p.pos, p.grid, true, i
  from (values (1,'G','1:1'),(2,'D','2:4'),(3,'D','2:3'),(4,'D','2:2'),(5,'D','2:1'),(6,'M','3:3'),(7,'M','3:2'),(8,'M','3:1'),
               (9,'F','4:3'),(10,'F','4:2'),(11,'F','4:1')) p(i, pos, grid);
  insert into lineup_players(lineup_id, player_name, shirt_number, position, is_starter, sort_order)
  select l_home, firsts[i] || ' ' || names[i], i, 'M', false, i from generate_series(12, 16) i;

  insert into lineup_players(lineup_id, player_name, shirt_number, position, grid, is_starter, sort_order) values
    (l_away,'A. Idrissi',1,'G','1:1',true,1),(l_away,'H. Bennani',2,'D','2:4',true,2),(l_away,'K. Tazi',5,'D','2:3',true,3),
    (l_away,'M. Fassi',4,'D','2:2',true,4),(l_away,'S. Berrada',3,'D','2:1',true,5),(l_away,'R. Chraibi',6,'M','3:2',true,6),
    (l_away,'O. Lahlou',8,'M','3:1',true,7),(l_away,'N. Amrani',7,'M','4:3',true,8),(l_away,'Y. Alaoui',10,'M','4:2',true,9),
    (l_away,'I. Kettani',11,'M','4:1',true,10),(l_away,'Z. Benjelloun',9,'F','5:1',true,11),
    (l_away,'B. Sefrioui',12,'G',null,false,12),(l_away,'T. Ziani',14,'M',null,false,13);

  insert into fixture_stats(fixture_id, team_id, stats) values
    (f_live, (tid->>'SEN')::uuid, '{"Ball Possession":"54%","expected_goals":"1.32","Total Shots":11,"Shots on Goal":5,"Corner Kicks":6,"Fouls":9,"Offsides":2,"Yellow Cards":1,"Goalkeeper Saves":2,"Passes %":"84%"}'),
    (f_live, (tid->>'MAR')::uuid, '{"Ball Possession":"46%","expected_goals":"0.97","Total Shots":8,"Shots on Goal":3,"Corner Kicks":3,"Fouls":12,"Offsides":1,"Yellow Cards":1,"Goalkeeper Saves":4,"Passes %":"81%"}');

  -- ---------- classement Ligue 1 SN (démo) ----------
  insert into standings(competition_id, season, team_id, rank, points, played, win, draw, lose, goals_for, goals_against, form, zone)
  select c_l1, 2026, (tid->>v.code)::uuid, v.rk, v.w*3 + v.d, v.w + v.d + v.l, v.w, v.d, v.l, v.gf, v.ga, v.form, v.zone
  from (values
    ('TFC',1,4,1,1,11,4,'WWLWD','Promotion - CAF Champions League'),
    ('GFO',2,4,1,1,10,5,'WDWWW','Promotion - CAF Confederation Cup'),
    ('JAR',3,3,3,0, 8,4,'DWDWD',null),
    ('CAS',4,3,2,1, 9,6,'WLWDL',null),
    ('USG',5,3,1,2, 7,7,'LWDWL',null),
    ('ASP',6,2,3,1, 6,7,'DLDWL',null),
    ('SDM',7,2,2,2, 6,6,'WDLDL',null),
    ('DSC',8,2,1,3, 5,8,'LWLLD',null),
    ('WAL',9,1,3,2, 4,6,'DDLWD',null),
    ('LSL',10,1,2,3, 4,8,'LDLWD',null),
    ('JAM',11,1,1,4, 3,9,'LLDLW','Relegation'),
    ('GFC',12,0,2,4, 2,10,'LDLLL','Relegation')) v(code, rk, w, d, l, gf, ga, form, zone);

  select count(*) into n from fixtures f join competitions c on c.id = f.competition_id where c.is_demo;
  return format('Démo chargée : %s matchs, 15 équipes, 3 compétitions', n);
end $$;
revoke all on function public.seed_demo() from public, anon, authenticated;

select public.seed_demo();
