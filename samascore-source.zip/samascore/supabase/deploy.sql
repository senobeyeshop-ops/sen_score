-- =====================================================================
-- SamaScore — clone football de 365Scores — migration initiale
-- Cible : Supabase (Postgres 15+). Heures en timestamptz (UTC).
-- Accès : RLS. Données sportives = lecture publique, écriture service_role
-- (Edge Functions d'ingestion) ou admin. Données utilisateur = propriétaire.
-- =====================================================================

create schema if not exists extensions;
create extension if not exists pg_trgm with schema extensions;   -- recherche floue (S12)

-- ---------- fonctions utilitaires ----------
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

-- ---------- profils & rôles ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  locale text not null default 'fr',
  timezone text not null default 'Africa/Dakar',
  role text not null default 'user' check (role in ('user','admin')),
  premium_until timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
$$;

-- crée le profil à l'inscription
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(coalesce(new.email,''),'@',1)));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- référentiel sportif ----------
create table public.countries (
  code text primary key,                 -- 'SN', 'FR', 'WORLD'
  name text not null,
  flag_url text
);

create table public.competitions (
  id uuid primary key default gen_random_uuid(),
  provider text not null default 'api_football' check (provider in ('api_football','manual')),
  provider_id integer,                   -- league.id API-Football (null si manuel)
  name text not null,
  short_name text,
  country_code text references public.countries(code) on delete set null,
  type text not null check (type in ('league','cup')),
  logo_url text,
  current_season integer,                -- 2026 = saison 2026/27
  display_priority integer not null default 1000,  -- petit = affiché en haut (Ligue 1 SN, CAN…)
  is_active boolean not null default true,         -- ingérée par le worker ?
  is_demo boolean not null default false,          -- données de démonstration (seed_demo)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, provider_id)
);
create index on public.competitions (country_code);
create index on public.competitions (display_priority) where is_active;
create index competitions_name_trgm on public.competitions using gin (name extensions.gin_trgm_ops);

create table public.venues (
  id uuid primary key default gen_random_uuid(),
  provider_id integer unique,
  name text not null,
  city text,
  capacity integer,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.teams (
  id uuid primary key default gen_random_uuid(),
  provider text not null default 'api_football' check (provider in ('api_football','manual')),
  provider_id integer,
  name text not null,
  short_name text,
  code text,                             -- 'SEN', 'JAR'
  country_code text references public.countries(code) on delete set null,
  is_national boolean not null default false,
  logo_url text,
  venue_id uuid references public.venues(id) on delete set null,
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, provider_id)
);
create index on public.teams (country_code);
create index on public.teams (venue_id);
create index teams_name_trgm on public.teams using gin (name extensions.gin_trgm_ops);

create table public.players (
  id uuid primary key default gen_random_uuid(),
  provider_id integer unique,
  name text not null,
  firstname text,
  lastname text,
  birth_date date,
  nationality text,
  position text check (position in ('G','D','M','F')),
  photo_url text,
  current_team_id uuid references public.teams(id) on delete set null,
  shirt_number smallint,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.players (current_team_id);
create index players_name_trgm on public.players using gin (name extensions.gin_trgm_ops);

-- ---------- matchs ----------
create table public.fixtures (
  id uuid primary key default gen_random_uuid(),
  provider text not null default 'api_football' check (provider in ('api_football','manual')),
  provider_id integer,
  competition_id uuid not null references public.competitions(id) on delete cascade,
  season integer not null,
  round text,                            -- 'Regular Season - 7', 'Quarter-finals'
  home_team_id uuid not null references public.teams(id) on delete restrict,
  away_team_id uuid not null references public.teams(id) on delete restrict,
  venue_id uuid references public.venues(id) on delete set null,
  referee text,
  kickoff_at timestamptz not null,
  -- statuts courts d'API-Football
  status text not null default 'NS' check (status in
    ('TBD','NS','1H','HT','2H','ET','BT','P','SUSP','INT','FT','AET','PEN','PST','CANC','ABD','AWD','WO','LIVE')),
  elapsed smallint,                      -- minute
  extra_time smallint,                   -- +3 du temps additionnel
  home_goals smallint,
  away_goals smallint,
  home_ht smallint, away_ht smallint,
  home_et smallint, away_et smallint,
  home_pen smallint, away_pen smallint,
  tv_channels text[] not null default '{}',
  has_lineups boolean not null default false,
  lineups_confirmed boolean not null default false,
  last_synced_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, provider_id),
  constraint fixtures_distinct_teams check (home_team_id <> away_team_id)
);
create index on public.fixtures (kickoff_at);
create index on public.fixtures (competition_id, kickoff_at);
create index on public.fixtures (home_team_id, kickoff_at);
create index on public.fixtures (away_team_id, kickoff_at);
create index on public.fixtures (venue_id);
create index fixtures_live_idx on public.fixtures (status)
  where status in ('1H','HT','2H','ET','BT','P','SUSP','INT','LIVE');
-- un même duel ne peut pas exister deux fois au même coup d'envoi (protège la saisie manuelle)
create unique index fixtures_no_dup on public.fixtures (home_team_id, away_team_id, kickoff_at);

create table public.fixture_events (
  id uuid primary key default gen_random_uuid(),
  fixture_id uuid not null references public.fixtures(id) on delete cascade,
  team_id uuid references public.teams(id) on delete set null,
  player_id uuid references public.players(id) on delete set null,
  assist_player_id uuid references public.players(id) on delete set null,
  player_name text,                      -- dénormalisé : l'API n'a pas toujours l'id joueur
  assist_name text,
  minute smallint not null,
  extra_minute smallint,
  type text not null check (type in ('goal','card','subst','var')),
  detail text,                           -- 'Normal Goal','Own Goal','Penalty','Yellow Card','Red Card'…
  comments text,
  -- empreinte stable pour dédupliquer d'un poll à l'autre
  dedup_key text not null,
  notified_at timestamptz,               -- push envoyé (idempotence)
  created_at timestamptz not null default now(),
  unique (fixture_id, dedup_key)
);
create index on public.fixture_events (fixture_id, minute, extra_minute);
create index on public.fixture_events (team_id);
create index on public.fixture_events (player_id);
create index on public.fixture_events (assist_player_id);

create table public.fixture_lineups (
  id uuid primary key default gen_random_uuid(),
  fixture_id uuid not null references public.fixtures(id) on delete cascade,
  team_id uuid not null references public.teams(id) on delete cascade,
  formation text,                        -- '4-3-3'
  coach_name text,
  is_confirmed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (fixture_id, team_id)
);
create index on public.fixture_lineups (team_id);

create table public.lineup_players (
  id uuid primary key default gen_random_uuid(),
  lineup_id uuid not null references public.fixture_lineups(id) on delete cascade,
  player_id uuid references public.players(id) on delete set null,
  player_name text not null,
  shirt_number smallint,
  position text,
  grid text,                             -- '2:3' (ligne:colonne sur le terrain)
  is_starter boolean not null,
  sort_order smallint not null default 0
);
create index on public.lineup_players (lineup_id, is_starter, sort_order);
create index on public.lineup_players (player_id);

create table public.fixture_stats (
  fixture_id uuid not null references public.fixtures(id) on delete cascade,
  team_id uuid not null references public.teams(id) on delete cascade,
  stats jsonb not null default '{}',     -- {"Ball Possession":"55%","Total Shots":12,"expected_goals":"1.4"}
  updated_at timestamptz not null default now(),
  primary key (fixture_id, team_id)
);
create index on public.fixture_stats (team_id);

-- ---------- classements ----------
create table public.standings (
  id uuid primary key default gen_random_uuid(),
  competition_id uuid not null references public.competitions(id) on delete cascade,
  season integer not null,
  group_name text not null default '',   -- 'Group A' pour CAN/CAF, '' sinon
  team_id uuid not null references public.teams(id) on delete cascade,
  rank smallint not null,
  points smallint not null default 0,
  played smallint not null default 0,
  win smallint not null default 0,
  draw smallint not null default 0,
  lose smallint not null default 0,
  goals_for smallint not null default 0,
  goals_against smallint not null default 0,
  form text,                             -- 'WWDLW'
  zone text,                             -- 'Promotion - CAF Champions League', 'Relegation'
  updated_at timestamptz not null default now(),
  unique (competition_id, season, group_name, team_id)
);
create index on public.standings (competition_id, season, group_name, rank);
create index on public.standings (team_id);

-- ---------- actualités (titre + lien uniquement) ----------
create table public.news_articles (
  id uuid primary key default gen_random_uuid(),
  source_name text not null,
  url text not null unique,
  title text not null,
  image_url text,
  published_at timestamptz not null,
  team_ids uuid[] not null default '{}',
  created_at timestamptz not null default now()
);
create index on public.news_articles (published_at desc);
create index on public.news_articles using gin (team_ids);

-- ---------- utilisateur : favoris & notifications ----------
create table public.follows (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  target_type text not null check (target_type in ('team','competition','fixture')),
  team_id uuid references public.teams(id) on delete cascade,
  competition_id uuid references public.competitions(id) on delete cascade,
  fixture_id uuid references public.fixtures(id) on delete cascade,
  -- alertes par cible (corrige le bug de l'original : off = off)
  notify_goals boolean not null default true,
  notify_red_cards boolean not null default true,
  notify_kickoff boolean not null default true,
  notify_final boolean not null default true,
  notify_lineups boolean not null default false,
  muted boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint follows_one_target check (
    (target_type = 'team'        and team_id is not null and competition_id is null and fixture_id is null) or
    (target_type = 'competition' and competition_id is not null and team_id is null and fixture_id is null) or
    (target_type = 'fixture'     and fixture_id is not null and team_id is null and competition_id is null))
);
create unique index follows_team_uq on public.follows (user_id, team_id) where team_id is not null;
create unique index follows_comp_uq on public.follows (user_id, competition_id) where competition_id is not null;
create unique index follows_fix_uq  on public.follows (user_id, fixture_id) where fixture_id is not null;
create index on public.follows (team_id) where team_id is not null;
create index on public.follows (competition_id) where competition_id is not null;
create index on public.follows (fixture_id) where fixture_id is not null;

create table public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  user_agent text,
  failure_count smallint not null default 0,
  last_used_at timestamptz,
  created_at timestamptz not null default now()
);
create index on public.push_subscriptions (user_id);

-- journal d'envoi : une notif par (abonnement, événement) maximum
create table public.notification_log (
  id uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references public.push_subscriptions(id) on delete cascade,
  fixture_id uuid not null references public.fixtures(id) on delete cascade,
  kind text not null check (kind in ('goal','red_card','kickoff','final','lineups','goal_cancelled')),
  ref_key text not null,                 -- dedup_key de l'événement ou statut
  sent_at timestamptz not null default now(),
  unique (subscription_id, fixture_id, kind, ref_key)
);
create index on public.notification_log (fixture_id);

-- ---------- pronostics entre amis (sans argent) ----------
create table public.prediction_groups (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  invite_code text not null unique default upper(substr(md5(gen_random_uuid()::text), 1, 6)),
  competition_id uuid references public.competitions(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.prediction_groups (owner_id);
create index on public.prediction_groups (competition_id);

create table public.prediction_group_members (
  group_id uuid not null references public.prediction_groups(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (group_id, user_id)
);
create index on public.prediction_group_members (user_id);

create table public.predictions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  fixture_id uuid not null references public.fixtures(id) on delete cascade,
  home_goals smallint not null check (home_goals between 0 and 20),
  away_goals smallint not null check (away_goals between 0 and 20),
  points smallint,                       -- 3 score exact, 1 bon résultat, 0 sinon ; null = pas encore calculé
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, fixture_id)
);
create index on public.predictions (fixture_id);

-- verrou serveur : pas de prono (création ou modif) après le coup d'envoi
create or replace function public.lock_prediction() returns trigger
language plpgsql as $$
declare k timestamptz;
begin
  -- service_role ou calcul des points déclenché par la fin du match (trigger imbriqué)
  if current_setting('request.jwt.claim.role', true) = 'service_role' or pg_trigger_depth() > 1 then
    return new;
  end if;
  select kickoff_at into k from public.fixtures where id = new.fixture_id;
  if k is null or now() >= k then
    raise exception 'Pronostic fermé : le match a commencé' using errcode = 'P0001';
  end if;
  new.points := null;  -- un utilisateur ne fixe jamais ses points
  return new;
end $$;
create trigger predictions_lock before insert or update on public.predictions
  for each row execute function public.lock_prediction();

create view public.group_leaderboard with (security_invoker = true) as
select m.group_id, m.user_id, p2.display_name,
       coalesce(sum(p.points), 0)::int as total_points,
       count(p.points) filter (where p.points = 3)::int as exact_scores
from public.prediction_group_members m
join public.profiles p2 on p2.id = m.user_id
join public.prediction_groups g on g.id = m.group_id
left join public.predictions p on p.user_id = m.user_id
left join public.fixtures f on f.id = p.fixture_id
     and (g.competition_id is null or f.competition_id = g.competition_id)
where p.id is null or f.id is not null
group by m.group_id, m.user_id, p2.display_name;

-- ---------- paiements premium (Wave / Orange Money) ----------
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null check (provider in ('wave','orange_money')),
  provider_ref text unique,              -- id de session/transaction fournisseur (idempotence webhook)
  amount_xof integer not null check (amount_xof > 0),   -- FCFA : pas de centimes
  currency text not null default 'XOF',
  plan text not null check (plan in ('monthly','yearly')),
  status text not null default 'pending' check (status in ('pending','succeeded','failed','refunded')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.payments (user_id, created_at desc);

-- ---------- pilotage de l'ingestion ----------
create table public.sync_state (
  job text primary key,                  -- 'live', 'fixtures_daily', 'standings', 'lineups'
  last_run_at timestamptz,
  last_ok_at timestamptz,
  last_error text,
  cursor jsonb not null default '{}'
);

create table public.api_usage (
  day date not null,
  provider text not null default 'api_football',
  requests integer not null default 0,
  remaining integer,                     -- en-tête x-ratelimit-requests-remaining
  primary key (day, provider)
);

-- ---------- triggers updated_at ----------
do $$
declare t text;
begin
  foreach t in array array['profiles','competitions','venues','teams','players','fixtures',
                           'fixture_lineups','follows','prediction_groups','predictions','payments']
  loop
    execute format('create trigger %I_updated_at before update on public.%I
                    for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

-- =====================================================================
-- RLS
-- =====================================================================
alter table public.profiles                 enable row level security;
alter table public.countries                enable row level security;
alter table public.competitions             enable row level security;
alter table public.venues                   enable row level security;
alter table public.teams                    enable row level security;
alter table public.players                  enable row level security;
alter table public.fixtures                 enable row level security;
alter table public.fixture_events           enable row level security;
alter table public.fixture_lineups          enable row level security;
alter table public.lineup_players           enable row level security;
alter table public.fixture_stats            enable row level security;
alter table public.standings                enable row level security;
alter table public.news_articles            enable row level security;
alter table public.follows                  enable row level security;
alter table public.push_subscriptions       enable row level security;
alter table public.notification_log         enable row level security;
alter table public.prediction_groups        enable row level security;
alter table public.prediction_group_members enable row level security;
alter table public.predictions              enable row level security;
alter table public.payments                 enable row level security;
alter table public.sync_state               enable row level security;
alter table public.api_usage                enable row level security;

-- référentiel : lecture pour tous (même invités), écriture admin ; service_role contourne la RLS
do $$
declare t text;
begin
  foreach t in array array['countries','competitions','venues','teams','players','fixtures',
                           'fixture_events','fixture_lineups','lineup_players','fixture_stats',
                           'standings','news_articles']
  loop
    execute format('create policy %I on public.%I for select to anon, authenticated using (true)',
                   t || '_read', t);
    execute format('create policy %I on public.%I for all to authenticated
                    using (public.is_admin()) with check (public.is_admin())', t || '_admin_write', t);
  end loop;
end $$;

-- helpers security definer : évitent la récursion RLS entre tables qui se référencent
create or replace function public.is_group_member(p_group uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from prediction_group_members where group_id = p_group and user_id = auth.uid())
$$;
create or replace function public.shares_group_with(p_user uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from prediction_group_members a
                 join prediction_group_members b on a.group_id = b.group_id
                 where a.user_id = auth.uid() and b.user_id = p_user)
$$;

-- profils
create policy profiles_self_read on public.profiles for select to authenticated
  using (id = (select auth.uid()) or public.is_admin() or public.shares_group_with(id));
create policy profiles_self_update on public.profiles for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));

-- rôle et premium ne se changent jamais depuis le client
create or replace function public.protect_profile_fields() returns trigger
language plpgsql as $$
begin
  if current_setting('request.jwt.claim.role', true) = 'service_role' or current_user = 'postgres'
     or public.is_admin() then return new; end if;
  new.role := old.role;
  new.premium_until := old.premium_until;
  return new;
end $$;
create trigger profiles_protect before update on public.profiles
  for each row execute function public.protect_profile_fields();

-- favoris & abonnements push : strictement au propriétaire
create policy follows_owner on public.follows for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy push_owner on public.push_subscriptions for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
-- notification_log, sync_state, api_usage : aucune policy → service_role uniquement

-- groupes de pronos
create policy pg_member_read on public.prediction_groups for select to authenticated
  using (owner_id = (select auth.uid()) or public.is_group_member(id));
create policy pg_owner_write on public.prediction_groups for all to authenticated
  using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));
create policy pgm_read on public.prediction_group_members for select to authenticated
  using (public.is_group_member(group_id));
create policy pgm_leave on public.prediction_group_members for delete to authenticated
  using (user_id = (select auth.uid()));
-- rejoindre se fait via la fonction join_group(code), pas d'insert direct

-- pronostics : j'écris les miens ; je vois ceux de mes co-membres une fois le match commencé
create policy pred_owner_write on public.predictions for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy pred_peers_read on public.predictions for select to authenticated
  using (exists (select 1 from public.fixtures f where f.id = predictions.fixture_id and f.kickoff_at <= now())
         and public.shares_group_with(user_id));

-- paiements : lecture du propriétaire ; écriture par webhook (service_role)
create policy payments_owner_read on public.payments for select to authenticated
  using (user_id = (select auth.uid()));

-- rejoindre un groupe par code d'invitation
create or replace function public.join_group(p_code text) returns uuid
language plpgsql security definer set search_path = public as $$
declare g uuid;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select id into g from public.prediction_groups where invite_code = upper(trim(p_code));
  if g is null then raise exception 'Code invalide'; end if;
  insert into public.prediction_group_members (group_id, user_id) values (g, auth.uid())
  on conflict do nothing;
  return g;
end $$;
revoke all on function public.join_group(text) from public;
grant execute on function public.join_group(text) to authenticated;

-- le propriétaire devient membre de son groupe
create or replace function public.add_owner_as_member() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.prediction_group_members (group_id, user_id) values (new.id, new.owner_id)
  on conflict do nothing;
  return new;
end $$;
create trigger prediction_groups_owner_member after insert on public.prediction_groups
  for each row execute function public.add_owner_as_member();

-- calcul des points à la fin d'un match (appelé par le trigger ci-dessous)
create or replace function public.score_predictions() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status in ('FT','AET','PEN') and old.status is distinct from new.status then
    update public.predictions p set points = case
        when p.home_goals = new.home_goals and p.away_goals = new.away_goals then 3
        when sign(p.home_goals - p.away_goals) = sign(new.home_goals - new.away_goals) then 1
        else 0 end
    where p.fixture_id = new.id;
  elsif new.status in ('CANC','ABD','PST') and old.status is distinct from new.status then
    update public.predictions set points = null where fixture_id = new.id;
  end if;
  return new;
end $$;
create trigger fixtures_score_predictions after update of status on public.fixtures
  for each row execute function public.score_predictions();

-- recherche (S12) : une seule requête pour équipes, compétitions, joueurs — insensible aux accents
create extension if not exists unaccent with schema extensions;
create or replace function public.search_all(q text, lim int default 20)
returns table (kind text, id uuid, name text, logo_url text, score real)
language sql stable set search_path = public, extensions as $$
  with s as (select unaccent(lower(trim(q))) as k)
  (select 'team', t.id, t.name, t.logo_url,
          case when unaccent(lower(t.name)) like s.k || '%' then 1 else similarity(unaccent(lower(t.name)), s.k) end
   from teams t, s where unaccent(lower(t.name)) like '%' || s.k || '%' or unaccent(lower(t.name)) % s.k)
  union all
  (select 'competition', c.id, c.name, c.logo_url,
          case when unaccent(lower(c.name)) like s.k || '%' then 1 else similarity(unaccent(lower(c.name)), s.k) end
   from competitions c, s where unaccent(lower(c.name)) like '%' || s.k || '%' or unaccent(lower(c.name)) % s.k)
  union all
  (select 'player', p.id, p.name, p.photo_url,
          case when unaccent(lower(p.name)) like s.k || '%' then 1 else similarity(unaccent(lower(p.name)), s.k) end
   from players p, s where unaccent(lower(p.name)) like '%' || s.k || '%' or unaccent(lower(p.name)) % s.k)
  order by 5 desc, 3 limit lim
$$;
grant execute on function public.search_all(text, int) to anon, authenticated;

-- Realtime : diffuser score/minute/événements aux clients
alter publication supabase_realtime add table public.fixtures, public.fixture_events;
-- =====================================================================
-- SamaScore — données de démonstration
-- Matchs placés autour de l'heure actuelle : relance `select public.seed_demo();`
-- dans l'éditeur SQL pour remettre la démo « en direct » quand tu veux.
-- Joueurs et compositions fictifs. Ne touche jamais aux données non-démo.
-- =====================================================================
create or replace function public.seed_demo() returns text
language plpgsql security definer set search_path = public as $$
declare
  c_amical uuid; c_l1 uuid; c_caf uuid;
  t record; tid jsonb := '{}';
  f_live uuid; f_ht uuid; f_ft uuid; l_home uuid; l_away uuid;
  d0 timestamptz := date_trunc('day', now());
  n int := 0;
  names text[] := array['Diop','Ndiaye','Fall','Sarr','Gueye','Faye','Ba','Sow','Cissé','Mbaye','Seck','Diallo','Kane','Niang','Thiam','Camara'];
  firsts text[] := array['Moussa','Cheikh','Pape','Ibrahima','Mamadou','Lamine','Abdou','Ousmane','Aliou','Babacar','Serigne','Malick','Amadou','Saliou','Modou','Ismaïla'];
begin
  -- on repart de zéro pour la démo uniquement
  delete from competitions where is_demo;
  delete from teams where is_demo;

  insert into countries(code, name) values ('SN','Sénégal'),('MA','Maroc'),('EG','Égypte'),('WORLD','International')
  on conflict (code) do nothing;

  insert into competitions(provider, name, short_name, country_code, type, current_season, display_priority, is_demo)
  values ('manual','Matchs internationaux','Internationaux','WORLD','cup',2026,5,true) returning id into c_amical;
  insert into competitions(provider, name, short_name, country_code, type, current_season, display_priority, is_demo)
  values ('manual','Ligue 1 Sénégal','Ligue 1 SN','SN','league',2026,10,true) returning id into c_l1;
  insert into competitions(provider, name, short_name, country_code, type, current_season, display_priority, is_demo)
  values ('manual','Ligue des champions CAF','LdC CAF','WORLD','cup',2026,20,true) returning id into c_caf;

  for t in select * from (values
    ('Sénégal','SEN','SN',true),('Maroc','MAR','MA',true),
    ('ASC Jaraaf','JAR','SN',false),('Teungueth FC','TFC','SN',false),('Génération Foot','GFO','SN',false),
    ('Casa Sports','CAS','SN',false),('AS Pikine','ASP','SN',false),('US Gorée','USG','SN',false),
    ('Guédiawaye FC','GFC','SN',false),('Dakar Sacré-Cœur','DSC','SN',false),('Stade de Mbour','SDM','SN',false),
    ('Jamono Fatick','JAM','SN',false),('Wally Daan','WAL','SN',false),('Linguère de Saint-Louis','LSL','SN',false),
    ('Al Ahly','AHL','EG',false)) v(name, code, cc, nat)
  loop
    insert into teams(provider, name, short_name, code, country_code, is_national, is_demo)
    values ('manual', t.name, t.name, t.code, t.cc, t.nat, true)
    returning jsonb_set(tid, array[t.code], to_jsonb(id)) into tid;
  end loop;

  -- ---------- matchs ----------
  -- Sénégal – Maroc : en direct, 67e
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at, status, elapsed,
                       home_goals, away_goals, home_ht, away_ht, referee, tv_channels, has_lineups, lineups_confirmed)
  values ('manual', c_amical, 2026, 'Match amical', (tid->>'SEN')::uuid, (tid->>'MAR')::uuid, now() - interval '82 minutes',
          '2H', 67, 1, 1, 1, 0, 'Arbitre de démonstration', '{RTS 1}', true, true) returning id into f_live;

  -- Jaraaf – Teungueth : mi-temps
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at, status, elapsed,
                       home_goals, away_goals, home_ht, away_ht)
  values ('manual', c_l1, 2026, 'Journée 7', (tid->>'JAR')::uuid, (tid->>'TFC')::uuid, now() - interval '50 minutes',
          'HT', 45, 0, 1, 0, 1) returning id into f_ht;

  -- Génération Foot – Casa : terminé
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at, status, elapsed,
                       home_goals, away_goals, home_ht, away_ht)
  values ('manual', c_l1, 2026, 'Journée 7', (tid->>'GFO')::uuid, (tid->>'CAS')::uuid, now() - interval '3 hours',
          'FT', 90, 2, 1, 1, 1) returning id into f_ft;

  -- à venir aujourd'hui, demain, et la suite
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at) values
    ('manual', c_l1, 2026, 'Journée 7', (tid->>'ASP')::uuid, (tid->>'USG')::uuid, now() + interval '2 hours'),
    ('manual', c_l1, 2026, 'Journée 7', (tid->>'GFC')::uuid, (tid->>'DSC')::uuid, now() + interval '4 hours'),
    ('manual', c_l1, 2026, 'Journée 7', (tid->>'SDM')::uuid, (tid->>'JAM')::uuid, d0 + interval '1 day 16 hours 30 minutes'),
    ('manual', c_l1, 2026, 'Journée 7', (tid->>'WAL')::uuid, (tid->>'LSL')::uuid, d0 + interval '1 day 19 hours'),
    ('manual', c_caf, 2026, 'Phase de groupes - J3', (tid->>'AHL')::uuid, (tid->>'JAR')::uuid, d0 + interval '2 days 17 hours'),
    ('manual', c_l1, 2026, 'Journée 8', (tid->>'TFC')::uuid, (tid->>'GFO')::uuid, d0 + interval '6 days 16 hours 30 minutes'),
    ('manual', c_l1, 2026, 'Journée 8', (tid->>'CAS')::uuid, (tid->>'JAR')::uuid, d0 + interval '6 days 19 hours');

  -- résultats d'hier et d'avant-hier
  insert into fixtures(provider, competition_id, season, round, home_team_id, away_team_id, kickoff_at, status, elapsed, home_goals, away_goals, home_ht, away_ht) values
    ('manual', c_l1, 2026, 'Journée 6', (tid->>'TFC')::uuid, (tid->>'ASP')::uuid, d0 - interval '1 day' + interval '16 hours 30 minutes', 'FT', 90, 3, 0, 1, 0),
    ('manual', c_l1, 2026, 'Journée 6', (tid->>'USG')::uuid, (tid->>'JAR')::uuid, d0 - interval '1 day' + interval '19 hours', 'FT', 90, 1, 1, 0, 1),
    ('manual', c_l1, 2026, 'Journée 6', (tid->>'CAS')::uuid, (tid->>'GFC')::uuid, d0 - interval '2 days' + interval '16 hours 30 minutes', 'FT', 90, 2, 0, 2, 0),
    ('manual', c_l1, 2026, 'Journée 6', (tid->>'DSC')::uuid, (tid->>'GFO')::uuid, d0 - interval '2 days' + interval '19 hours', 'FT', 90, 0, 2, 0, 1);

  -- ---------- événements ----------
  insert into fixture_events(fixture_id, team_id, player_name, assist_name, minute, extra_minute, type, detail, dedup_key) values
    (f_live, (tid->>'SEN')::uuid, 'Cheikh Diop', 'Pape Sarr', 23, null, 'goal', 'Normal Goal', 'demo-1'),
    (f_live, (tid->>'MAR')::uuid, 'Y. Alaoui', null, 31, null, 'card', 'Yellow Card', 'demo-2'),
    (f_live, (tid->>'SEN')::uuid, 'Ibrahima Fall', null, 44, 2, 'card', 'Yellow Card', 'demo-3'),
    (f_live, (tid->>'MAR')::uuid, 'Y. Alaoui', 'H. Bennani', 58, null, 'goal', 'Penalty', 'demo-4'),
    (f_live, (tid->>'SEN')::uuid, 'Ousmane Ba', 'Moussa Gueye', 63, null, 'subst', 'Substitution 1', 'demo-5'),
    (f_ht,   (tid->>'TFC')::uuid, 'Lamine Seck', 'Abdou Faye', 38, null, 'goal', 'Normal Goal', 'demo-6'),
    (f_ft,   (tid->>'GFO')::uuid, 'Malick Thiam', null, 12, null, 'goal', 'Normal Goal', 'demo-7'),
    (f_ft,   (tid->>'CAS')::uuid, 'Saliou Kane', null, 40, null, 'goal', 'Penalty', 'demo-8'),
    (f_ft,   (tid->>'CAS')::uuid, 'Modou Niang', null, 71, null, 'card', 'Red Card', 'demo-9'),
    (f_ft,   (tid->>'GFO')::uuid, 'Malick Thiam', 'Aliou Camara', 88, null, 'goal', 'Normal Goal', 'demo-10');

  -- ---------- compositions (fictives) du match en direct ----------
  insert into fixture_lineups(fixture_id, team_id, formation, coach_name, is_confirmed)
  values (f_live, (tid->>'SEN')::uuid, '4-3-3', 'Sélectionneur (démo)', true) returning id into l_home;
  insert into fixture_lineups(fixture_id, team_id, formation, coach_name, is_confirmed)
  values (f_live, (tid->>'MAR')::uuid, '4-2-3-1', 'Sélectionneur (démo)', true) returning id into l_away;

  insert into lineup_players(lineup_id, player_name, shirt_number, position, grid, is_starter, sort_order)
  select l_home, firsts[i] || ' ' || names[i], i, p.pos, p.grid, true, i
  from (values (1,'G','1:1'),(2,'D','2:4'),(3,'D','2:3'),(4,'D','2:2'),(5,'D','2:1'),(6,'M','3:3'),(7,'M','3:2'),(8,'M','3:1'),
               (9,'F','4:3'),(10,'F','4:2'),(11,'F','4:1')) p(i, pos, grid);
  insert into lineup_players(lineup_id, player_name, shirt_number, position, is_starter, sort_order)
  select l_home, firsts[i] || ' ' || names[i], i, 'M', false, i from generate_series(12, 16) i;

  insert into lineup_players(lineup_id, player_name, shirt_number, position, grid, is_starter, sort_order) values
    (l_away,'A. Idrissi',1,'G','1:1',true,1),(l_away,'H. Bennani',2,'D','2:4',true,2),(l_away,'K. Tazi',5,'D','2:3',true,3),
    (l_away,'M. Fassi',4,'D','2:2',true,4),(l_away,'S. Berrada',3,'D','2:1',true,5),(l_away,'R. Chraibi',6,'M','3:2',true,6),
    (l_away,'O. Lahlou',8,'M','3:1',true,7),(l_away,'N. Amrani',7,'M','4:3',true,8),(l_away,'Y. Alaoui',10,'M','4:2',true,9),
    (l_away,'I. Kettani',11,'M','4:1',true,10),(l_away,'Z. Benjelloun',9,'F','5:1',true,11),
    (l_away,'B. Sefrioui',12,'G',null,false,12),(l_away,'T. Ziani',14,'M',null,false,13);

  insert into fixture_stats(fixture_id, team_id, stats) values
    (f_live, (tid->>'SEN')::uuid, '{"Ball Possession":"54%","expected_goals":"1.32","Total Shots":11,"Shots on Goal":5,"Corner Kicks":6,"Fouls":9,"Offsides":2,"Yellow Cards":1,"Goalkeeper Saves":2,"Passes %":"84%"}'),
    (f_live, (tid->>'MAR')::uuid, '{"Ball Possession":"46%","expected_goals":"0.97","Total Shots":8,"Shots on Goal":3,"Corner Kicks":3,"Fouls":12,"Offsides":1,"Yellow Cards":1,"Goalkeeper Saves":4,"Passes %":"81%"}');

  -- ---------- classement Ligue 1 SN (démo) ----------
  insert into standings(competition_id, season, team_id, rank, points, played, win, draw, lose, goals_for, goals_against, form, zone)
  select c_l1, 2026, (tid->>v.code)::uuid, v.rk, v.w*3 + v.d, v.w + v.d + v.l, v.w, v.d, v.l, v.gf, v.ga, v.form, v.zone
  from (values
    ('TFC',1,4,1,1,11,4,'WWLWD','Promotion - CAF Champions League'),
    ('GFO',2,4,1,1,10,5,'WDWWW','Promotion - CAF Confederation Cup'),
    ('JAR',3,3,3,0, 8,4,'DWDWD',null),
    ('CAS',4,3,2,1, 9,6,'WLWDL',null),
    ('USG',5,3,1,2, 7,7,'LWDWL',null),
    ('ASP',6,2,3,1, 6,7,'DLDWL',null),
    ('SDM',7,2,2,2, 6,6,'WDLDL',null),
    ('DSC',8,2,1,3, 5,8,'LWLLD',null),
    ('WAL',9,1,3,2, 4,6,'DDLWD',null),
    ('LSL',10,1,2,3, 4,8,'LDLWD',null),
    ('JAM',11,1,1,4, 3,9,'LLDLW','Relegation'),
    ('GFC',12,0,2,4, 2,10,'LDLLL','Relegation')) v(code, rk, w, d, l, gf, ga, form, zone);

  select count(*) into n from fixtures f join competitions c on c.id = f.competition_id where c.is_demo;
  return format('Démo chargée : %s matchs, 15 équipes, 3 compétitions', n);
end $$;
revoke all on function public.seed_demo() from public, anon, authenticated;

select public.seed_demo();
